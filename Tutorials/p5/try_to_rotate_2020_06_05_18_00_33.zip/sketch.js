function setup() {
  createCanvas(400, 400);
}

function draw() {
  float m
  background(255,255,0);
  
}